import { LibraryAdmin } from "@/components/library-admin"

export default function Home() {
  return <LibraryAdmin />
}
