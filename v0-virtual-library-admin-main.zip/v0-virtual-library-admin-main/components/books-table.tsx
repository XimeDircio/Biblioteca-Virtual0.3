"use client"

import { Button } from "@/components/ui/button"
import { RotateCcw, BookOpen, Trash2, MoreHorizontal } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import type { Book } from "@/lib/types"

interface BooksTableProps {
  libros: Book[]
  onPrestar: (id: number) => void
  onDevolver: (id: number) => void
  onEliminar: (id: number) => void
}

export function BooksTable({ libros, onPrestar, onDevolver, onEliminar }: BooksTableProps) {
  const getEstadoBadge = (estado: string) => {
    const styles = {
      Disponible: "bg-green-100 text-green-700 border-green-200",
      Prestado: "bg-amber-100 text-amber-700 border-amber-200",
      Retrasado: "bg-red-100 text-red-700 border-red-200",
    }
    return styles[estado as keyof typeof styles] || "bg-muted text-muted-foreground"
  }

  return (
    <div className="bg-white border border-border rounded-xl overflow-hidden shadow-sm">
      <div className="px-5 py-4 border-b border-border">
        <h2 className="text-sm font-semibold text-foreground">Inventario de Libros</h2>
      </div>

      <div className="divide-y divide-border">
        {libros.length === 0 ? (
          <div className="px-5 py-12 text-center">
            <BookOpen className="w-10 h-10 text-muted-foreground/50 mx-auto mb-3" />
            <p className="text-sm text-muted-foreground">No hay libros en el inventario</p>
          </div>
        ) : (
          libros.map((libro) => (
            <div
              key={libro.id}
              className="px-5 py-4 hover:bg-slate-50 transition-colors flex items-center justify-between gap-4"
            >
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground truncate">{libro.titulo}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{libro.autor}</p>
              </div>

              <div className="hidden sm:flex items-center gap-8 text-xs">
                <div className="text-center">
                  <p className="font-semibold text-foreground">{libro.formato}</p>
                  <p className="text-muted-foreground">Formato</p>
                </div>
                <div className="text-center">
                  <p className="font-semibold text-foreground">{libro.disponible}</p>
                  <p className="text-muted-foreground">Stock</p>
                </div>
                <div className="text-center">
                  <p className="font-semibold text-foreground">{libro.leido}</p>
                  <p className="text-muted-foreground">Lecturas</p>
                </div>
              </div>

              <span className={`px-2.5 py-1 text-xs font-medium rounded-full border ${getEstadoBadge(libro.estado)}`}>
                {libro.estado}
              </span>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-slate-100">
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => onPrestar(libro.id)} disabled={libro.disponible === 0}>
                    <BookOpen className="w-4 h-4 mr-2" />
                    Prestar
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => onDevolver(libro.id)}>
                    <RotateCcw className="w-4 h-4 mr-2" />
                    Devolver
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={() => onEliminar(libro.id)}
                    className="text-destructive focus:text-destructive"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Eliminar
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          ))
        )}
      </div>
    </div>
  )
}
