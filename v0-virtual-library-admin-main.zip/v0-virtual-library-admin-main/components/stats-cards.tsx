import { BookOpen, Users, Clock, TrendingUp } from "lucide-react"
import type { Book } from "@/lib/types"

interface StatsCardsProps {
  libros: Book[]
}

export function StatsCards({ libros }: StatsCardsProps) {
  const totalLibros = libros.length
  const disponibles = libros.filter((l) => l.disponible > 0).length
  const prestados = libros.filter((l) => l.estado === "Prestado").length
  const masLeido = libros.length > 0 ? libros.reduce((a, b) => (a.leido > b.leido ? a : b)) : null

  const stats = [
    {
      label: "Total Libros",
      value: totalLibros,
      icon: BookOpen,
      color: "text-primary",
      bg: "bg-green-50",
    },
    {
      label: "Disponibles",
      value: disponibles,
      icon: Users,
      color: "text-emerald-600",
      bg: "bg-emerald-50",
    },
    {
      label: "Prestados",
      value: prestados,
      icon: Clock,
      color: "text-amber-600",
      bg: "bg-amber-50",
    },
    {
      label: "Más Leído",
      value: masLeido?.leido ?? 0,
      subtitle: masLeido?.titulo.slice(0, 20) + "..." ?? "-",
      icon: TrendingUp,
      color: "text-blue-600",
      bg: "bg-blue-50",
    },
  ]

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {stats.map((stat) => (
        <div
          key={stat.label}
          className="bg-white border border-border rounded-xl p-4 hover:shadow-md hover:shadow-green-100/50 transition-all"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-muted-foreground">{stat.label}</span>
            <div className={`w-9 h-9 rounded-lg ${stat.bg} flex items-center justify-center`}>
              <stat.icon className={`w-4 h-4 ${stat.color}`} />
            </div>
          </div>
          <p className="text-2xl font-bold text-foreground">{stat.value}</p>
          {stat.subtitle && <p className="text-xs text-muted-foreground mt-1 truncate">{stat.subtitle}</p>}
        </div>
      ))}
    </div>
  )
}
