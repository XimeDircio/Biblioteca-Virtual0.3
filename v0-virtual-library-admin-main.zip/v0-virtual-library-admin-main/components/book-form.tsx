"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus } from "lucide-react"
import type { Book } from "@/lib/types"

interface BookFormProps {
  onSubmit: (libro: Omit<Book, "id" | "estado" | "leido">) => void
}

export function BookForm({ onSubmit }: BookFormProps) {
  const [titulo, setTitulo] = useState("")
  const [autor, setAutor] = useState("")
  const [formato, setFormato] = useState<string>("Físico")
  const [cantidad, setCantidad] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!titulo || !autor || !cantidad) return

    onSubmit({
      titulo,
      autor,
      formato: formato as Book["formato"],
      disponible: Number.parseInt(cantidad),
    })

    setTitulo("")
    setAutor("")
    setFormato("Físico")
    setCantidad("")
  }

  return (
    <div className="bg-white border border-border rounded-xl p-5 h-fit shadow-sm">
      <h2 className="text-sm font-semibold text-foreground mb-4">Agregar Libro</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-1.5">
          <Label htmlFor="titulo" className="text-xs text-muted-foreground">
            Título
          </Label>
          <Input
            id="titulo"
            type="text"
            placeholder="Nombre del libro"
            value={titulo}
            onChange={(e) => setTitulo(e.target.value)}
            required
            className="bg-slate-50 border-border text-sm h-10"
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="autor" className="text-xs text-muted-foreground">
            Autor
          </Label>
          <Input
            id="autor"
            type="text"
            placeholder="Nombre del autor"
            value={autor}
            onChange={(e) => setAutor(e.target.value)}
            required
            className="bg-slate-50 border-border text-sm h-10"
          />
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs text-muted-foreground">Formato</Label>
          <Select value={formato} onValueChange={setFormato}>
            <SelectTrigger className="bg-slate-50 border-border text-sm h-10">
              <SelectValue placeholder="Seleccionar formato" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Físico">Físico</SelectItem>
              <SelectItem value="Digital">Digital</SelectItem>
              <SelectItem value="Ambos">Ambos</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="cantidad" className="text-xs text-muted-foreground">
            Cantidad
          </Label>
          <Input
            id="cantidad"
            type="number"
            placeholder="Unidades disponibles"
            min="1"
            value={cantidad}
            onChange={(e) => setCantidad(e.target.value)}
            required
            className="bg-slate-50 border-border text-sm h-10"
          />
        </div>
        <Button type="submit" className="w-full bg-primary hover:bg-green-700 text-white h-10 font-medium">
          <Plus className="w-4 h-4 mr-2" />
          Agregar Libro
        </Button>
      </form>
    </div>
  )
}
