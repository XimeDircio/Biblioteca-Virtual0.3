"use client"

import { useState } from "react"
import { BookForm } from "./book-form"
import { BooksTable } from "./books-table"
import { StatsCards } from "./stats-cards"
import { LoginForm } from "./login-form"
import { BookOpen, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import type { Book } from "@/lib/types"

const initialBooks: Book[] = [
  {
    id: 1,
    titulo: "Cálculo Diferencial e Integral",
    autor: "Dennis G. Zill",
    formato: "Ambos",
    disponible: 5,
    estado: "Disponible",
    leido: 25,
  },
  {
    id: 2,
    titulo: "Física para Ingeniería",
    autor: "Raymond A. Serway",
    formato: "Físico",
    disponible: 2,
    estado: "Prestado",
    leido: 18,
  },
  {
    id: 3,
    titulo: "Fundamentos de Programación",
    autor: "Luis Joyanes Aguilar",
    formato: "Digital",
    disponible: 4,
    estado: "Disponible",
    leido: 30,
  },
  {
    id: 4,
    titulo: "Electrónica Básica",
    autor: "Albert Malvino",
    formato: "Físico",
    disponible: 0,
    estado: "Retrasado",
    leido: 12,
  },
  {
    id: 5,
    titulo: "Álgebra Lineal",
    autor: "David C. Lay",
    formato: "Digital",
    disponible: 1,
    estado: "Prestado",
    leido: 22,
  },
]

export function LibraryAdmin() {
  const [libros, setLibros] = useState<Book[]>(initialBooks)
  const [isLoggedIn, setIsLoggedIn] = useState(false)

  const agregarLibro = (nuevoLibro: Omit<Book, "id" | "estado" | "leido">) => {
    const libro: Book = {
      ...nuevoLibro,
      id: Date.now(),
      estado: "Disponible",
      leido: 0,
    }
    setLibros([...libros, libro])
  }

  const prestar = (id: number) => {
    setLibros(
      libros.map((libro) => {
        if (libro.id === id && libro.disponible > 0) {
          return {
            ...libro,
            disponible: libro.disponible - 1,
            estado: libro.disponible - 1 === 0 ? "Prestado" : "Disponible",
            leido: libro.leido + 1,
          }
        }
        return libro
      }),
    )
  }

  const devolver = (id: number) => {
    setLibros(
      libros.map((libro) => {
        if (libro.id === id) {
          const conRetraso = Math.random() < 0.25
          return {
            ...libro,
            disponible: libro.disponible + 1,
            estado: conRetraso ? "Retrasado" : "Disponible",
          }
        }
        return libro
      }),
    )
  }

  const eliminar = (id: number) => {
    setLibros(libros.filter((l) => l.id !== id))
  }

  if (!isLoggedIn) {
    return <LoginForm onLogin={() => setIsLoggedIn(true)} />
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-border px-6 py-4 sticky top-0 z-10">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
              <BookOpen className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-semibold text-foreground">Biblioteca Virtual</h1>
              <p className="text-xs text-muted-foreground">Panel de Administración</p>
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setIsLoggedIn(false)}
            className="text-muted-foreground hover:text-foreground hover:bg-slate-50"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Cerrar sesión
          </Button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-6 space-y-6">
        <StatsCards libros={libros} />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1">
            <BookForm onSubmit={agregarLibro} />
          </div>
          <div className="lg:col-span-2">
            <BooksTable libros={libros} onPrestar={prestar} onDevolver={devolver} onEliminar={eliminar} />
          </div>
        </div>
      </main>

      <footer className="bg-white border-t border-border px-6 py-4 mt-8">
        <p className="text-center text-sm text-muted-foreground">Biblioteca Virtual | Autor: DIRCIO ISC</p>
      </footer>
    </div>
  )
}
