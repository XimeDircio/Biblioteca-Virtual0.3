export interface Book {
  id: number
  titulo: string
  autor: string
  formato: "Físico" | "Digital" | "Ambos"
  disponible: number
  estado: "Disponible" | "Prestado" | "Retrasado"
  leido: number
}
